from django.shortcuts import render
from .models import*
from django.http import HttpResponse,JsonResponse
from django.core import serializers
import json
# Create your views here.
def index(request):
    return render(request,'homepage.html',{})
def homepage(request):
    return render(request,'homepage.html',{})
def employee(request):
    return render(request,'employee.html',{})
def employer(request):
    return render(request,'employer.html',{})

def Intinsert(request):
    try:
        print("Interviewer Time Slot Added")
        InterviewerID=request.GET.get("InterviewerID")
        Date=request.GET.get("Date")
        start_time=request.GET.get("start_time")
        end_time=request.GET.get("end_time") 
        addregob=Interviewer(Date=Date,start_time=start_time,end_time=end_time)
        addregob.save()
        return HttpResponse("successfull Added")
        
    except Exception as e:
        print(e)
        return HttpResponse("error on insertion")

def view_It(request):
    print("view It ok")
    try:
        
        o=Interviewer.objects.all()
        data={}
        if o:
            value=serializers.serialize("json",o)
            data['data1']=json.loads(value)
            return JsonResponse(data,safe=False)
        else:
            return HtttpResponse("No Data")
    except Exception as e:
        print("error",e)
        return HttpResponse("Error Occured")

