from django.db import models

# Create your models here.
class Interviewer(models.Model):
    Iid=models.IntegerField(primary_key=True)
    Date=models.CharField(max_length=200)
    start_time=models.CharField(max_length=200)
    end_time=models.CharField(max_length=200)